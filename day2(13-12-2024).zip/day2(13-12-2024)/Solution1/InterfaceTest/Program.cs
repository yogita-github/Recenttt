﻿namespace InterfaceTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Choose one option 1.AC 2.Fridge 3.Fan");
            int choice = Convert.ToInt32(Console.ReadLine());
            IAppliances iapp = getAppliances.choosedAppliances(choice);
            Console.WriteLine("Choose menu 1.price 2.weight 3.color");
            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    iapp.price();
                    break;
                case 2:
                    iapp.weight();
                    break;
                case 3:
                    iapp.color();
                    break;
                default:
                    break;
                    
            }
        }
    }
    public class getAppliances
    {
        public static IAppliances choosedAppliances(int i)
        {
            IAppliances appliances;
            if (i == 1)
            {
                appliances = new Ac();
                return appliances;
            }else if (i == 2)
            {
                appliances = new Fridge();
                return appliances;
            }
            else if(i == 3) 
            {
                    appliances = new Fan();
                    return appliances;
            }
            return null;
        }
    }

    public interface IAppliances
    {
       void price();
        void weight();
        void color();
    }
    public class Ac:IAppliances
    {
        public void price()
        {
            Console.WriteLine("400000");
        }
        public void weight()
        {
            Console.WriteLine("60kg");
        }
        public void color()
        {
            Console.WriteLine("green");
        }
    }
    public class Fridge:IAppliances
    {
        public void price()
        {
            Console.WriteLine("900000");
        }
        public void weight()
        {
            Console.WriteLine("70kg");
        }
        public void color()
        {
            Console.WriteLine("Red");
        }

    }
    public class Fan:IAppliances
    {
        public void price()
        {
            Console.WriteLine("5000");
        }
        public void weight()
        {
            Console.WriteLine("3kg");
        }
        public void color()
        {
            Console.WriteLine("Blue");
        }
    }
}
