﻿namespace Logger01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }

    #region Logger

    public class Logger
    {
        private static Logger logger1;
        private Logger()
        {
            logger1 = new Logger();
        }
        public static Logger getLogger()
        {
            return logger1;
        }

        public static void saveLog(string msg)
        {
            Console.WriteLine("Message : " + msg);
        }
        
    }

    public class getDatabaseClass
    {
        public static DbClass getDatabase(int i)
        {
            DbClass dbClass;

            if (i == 1)
            {
                dbClass = new MySql();
                return dbClass;
            }
            else if (i == 2)
            {
                dbClass = new MySql_Server();
                return dbClass;
            }
            else if (i == 3)
            {
                dbClass = new Oracle();
                return dbClass;
            }
            return null;
        }
    }

    public abstract class DbClass
    {
        public abstract void save();
        public abstract void update();
        public abstract void delete();
    }

    public class MySql : DbClass
    {
        Logger logger;
        public MySql()
        {
            
        }
        public override void save()
        {
            Console.WriteLine("Saved to MySql Database");
        }
        public override void update()
        {
            Console.WriteLine("updated to MySql Database");
        }
        public override void delete()
        {
            Console.WriteLine("delete to MySql Database");
        }
    }

    public class MySql_Server : DbClass
    {
        public override void save()
        {
            Console.WriteLine("Saved to MySql_Server Database");
        }
        public override void update()
        {
            Console.WriteLine("updated to MySql_Server Database");
        }
        public override void delete()
        {
            Console.WriteLine("delete to MySql_Server Database");
        }
    }

    public class Oracle : DbClass
    {
        public override void save()
        {
            Console.WriteLine("Saved to Oracle Database");
        }
        public override void update()
        {
            Console.WriteLine("updated to Oracle Database");
        }
        public override void delete()
        {
            Console.WriteLine("delete to Oracle Database");
        }
    } 
    #endregion

}
