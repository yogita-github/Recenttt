﻿namespace UtilFunction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }

    public interface FileType
    {
        void generateReport();
    }
   
    public abstract class MyFile : FileType
    {
        protected abstract void save();
        protected abstract void validate();
        protected abstract void parse();

        public virtual void generateReport()
        {
            parse();
            validate();
            save();
        }
    }
    public abstract class SpecialFile : MyFile
    {
        protected abstract void revalidate();

        public void generateReport()
        {
            parse();
            validate();
            revalidate();
            save();
        }
    }
    public class TXT : MyFile
    {
        protected override void save()
        {
            Console.WriteLine("data saved to Txt successfully");
        }
        protected override void validate()
        {
            Console.WriteLine("data validatede to Txt successfully");
        }
        protected override void parse()
        {
            Console.WriteLine("data parsed to Txt successfully");
        }
    }
    public class PDF : MyFile
    {
        protected override void save()
        {
            Console.WriteLine("data saved to PDF successfully");
        }
        protected override void validate()
        {
            Console.WriteLine("data validatede to PDF successfully");
        }
        protected override void parse()
        {
            Console.WriteLine("data parsed to PDF successfully");
        }
    }
    public class DOCX : MyFile
    {
        protected override void save()
        {
            Console.WriteLine("data saved to DOCX successfully");
        }
        protected override void validate()
        {
            Console.WriteLine("data validatede to DOCX successfully");
        }
        protected override void parse()
        {
            Console.WriteLine("data parsed to DOCX successfully");
        }
    }
    public class XML : SpecialFile
    {
        protected override void save()
        {
            Console.WriteLine("data added to XML successfully");
        }
        protected override void validate()
        {
            Console.WriteLine("data updated to XML successfully");
        }
        protected override void parse()
        {
            Console.WriteLine("data delete to XML successfully");
        }
        protected override void revalidate()
        {
            Console.WriteLine("this is newly added method");
        }

        
    }
}
