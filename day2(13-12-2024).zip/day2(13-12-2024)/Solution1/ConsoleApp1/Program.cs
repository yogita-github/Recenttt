﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region FactoryTesting
            Console.WriteLine("Select Database : 1. MySql  2. MySql Server 3. Oracle");
            int choice = Convert.ToInt32(Console.ReadLine());
            DbClass database = getDatabaseClass.getDatabase(choice);
            choice = 0;
            while (choice != 4)
            {
                Console.WriteLine("Select Database : 1. Save  2. Update  3. Delete  4. Exit");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        database.save();
                        break;
                    case 2:
                        database.update();
                        break;
                    case 3:
                        database.delete();
                        break;
                    case 4:

                        break;
                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                }
            }
            #endregion

        }
    }

    #region Factory Pattern
    public class getDatabaseClass
    {
        public static DbClass getDatabase(int i)
        {
            DbClass dbClass;

            if (i == 1)
            {
                dbClass = new MySql();
                return dbClass;
            }
            else if (i == 2)
            {
                dbClass = new MySql_Server();
                return dbClass;
            }
            else if (i == 3)
            {
                dbClass = new Oracle();
                return dbClass;
            }
            return null;
        }
    }

    public abstract class DbClass
    {
        public abstract void save();
        public abstract void update();
        public abstract void delete();
    }

    public class MySql : DbClass
    {
        public override void save()
        {
            Console.WriteLine("Saved to MySql Database");
        }
        public override void update()
        {
            Console.WriteLine("updated to MySql Database");
        }
        public override void delete()
        {
            Console.WriteLine("delete to MySql Database");
        }
    }

    public class MySql_Server : DbClass
    {
        public override void save()
        {
            Console.WriteLine("Saved to MySql_Server Database");
        }
        public override void update()
        {
            Console.WriteLine("updated to MySql_Server Database");
        }
        public override void delete()
        {
            Console.WriteLine("delete to MySql_Server Database");
        }
    }

    public class Oracle : DbClass
    {
        public override void save()
        {
            Console.WriteLine("Saved to Oracle Database");
        }
        public override void update()
        {
            Console.WriteLine("updated to Oracle Database");
        }
        public override void delete()
        {
            Console.WriteLine("delete to Oracle Database");
        }
    }
    #endregion

}
