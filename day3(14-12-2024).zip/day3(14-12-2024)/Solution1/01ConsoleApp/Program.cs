﻿namespace _01ConsoleApp
{
    // getter setter and constructor level dependency injection
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Test1
            //string ans = string.Format("i am {0} {1} and i am good", "Yogita", "Daku");
            //Console.WriteLine(ans);
            //Factory factory = new Factory();
            //ISpellChecker iss = factory.getSpellChecker("gr");
            //Notepad np = new Notepad(iss);
            //np.getSpellChecker(); 
            #endregion

            #region setter getter Test
            //DrSnape drs = new DrSnape();
            //drs.HairColor = "Black";
            //drs.Height = 6;
            //drs.Weight = 70;

            //Console.WriteLine(drs.HairColor);
            //Console.WriteLine(drs.Height);
            //Console.WriteLine(drs.HairColor); 
            #endregion
        }
    }

    #region Constructor dependency 
    //public class Notepad
    //{
    //    private ISpellChecker _ispellcherker;
    //    //constructor level dependency injection
    //    public Notepad(ISpellChecker ispellcherker)
    //    {
    //        if (ispellcherker == null)
    //        {
    //            this._ispellcherker = new EnglishChecker();
    //        }
    //        else
    //            this._ispellcherker = ispellcherker;
    //    }
    //    public void getSpellChecker()
    //    {
    //        _ispellcherker.DoSpellChecker();
    //    }
    //}


    //public class Factory
    //{
    //    public ISpellChecker getSpellChecker(string s)
    //    {
    //        ISpellChecker iss;
    //        switch (s)
    //        {
    //            case "en":
    //                iss = new EnglishChecker();
    //                break;
    //            case "sp":
    //                iss = new SpanishChecker();
    //                break;
    //            case "gr":
    //                iss = new GermanChecker();
    //                break;
    //            default:
    //                iss = new EnglishChecker();
    //                break;
    //        }
    //        return iss; ;
    //    }
    //}

    //public interface ISpellChecker
    //{
    //    void DoSpellChecker();
    //}

    //public class EnglishChecker : ISpellChecker
    //{
    //    public void DoSpellChecker()
    //    {
    //        Console.WriteLine("English spell checker");
    //    }
    //}
    //public class SpanishChecker : ISpellChecker
    //{
    //    public void DoSpellChecker()
    //    {
    //        Console.WriteLine("Spanish spell checker");
    //    }
    //}

    //public class GermanChecker : ISpellChecker
    //{
    //    public void DoSpellChecker()
    //    {
    //        Console.WriteLine("German spell checker");
    //    }
    //}

    //public class HindiChecker : ISpellChecker
    //{
    //    public void DoSpellChecker()
    //    {
    //        Console.WriteLine("Hindi spell checker");
    //    }
    //} 
    #endregion

    #region getter setter
    //public class DrSnape
    //{
    //    private int _height;
    //    private int _weight;
    //    private string _hairColor;

    //    public int Height
    //    {
    //        get { return _height; }
    //        set { _height = value; }
    //    }

    //    public int Weight
    //    {
    //        get { return _weight; }
    //        set { _weight = value; }
    //    }
    //    public string HairColor
    //    {
    //        get { return _hairColor; }
    //        set { _hairColor = value; }
    //    }
    //} 
    #endregion

}