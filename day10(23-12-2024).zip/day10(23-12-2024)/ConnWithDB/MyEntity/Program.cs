﻿using MyEntity.DAL;
using MyEntity.Model;

namespace MyEntity
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IETDbContext dbContext = new IETDbContext();
            while (true)
            {
                Console.WriteLine("Enter your choice 1.Select 2.Insert 3.Update 4.Delete");
                int opchoice = Convert.ToInt32(Console.ReadLine());
                switch (opchoice)
                {
                    case 1:
                        var allEmployees = dbContext.employees.ToList();
                        foreach(var emp in allEmployees)
                        {
                            Console.WriteLine($"Id:{emp.Id},Name:{emp.Name},Address : {emp.Address}");
                        }
                        break;
                    case 2:
                        Employee empToBeInserted = new Employee();
                        Console.WriteLine("Enter your name: ");
                        empToBeInserted.Name = Console.ReadLine();
                        Console.WriteLine("Enter your Address: ");
                        empToBeInserted.Address = Console.ReadLine();
                        dbContext.employees.Add(empToBeInserted);
                        dbContext.SaveChanges();
                        break;

                    case 3:
                        Console.WriteLine("Enter your id");
                        int id1 = Convert.ToInt32(Console.ReadLine());
                        Employee employeeToBeUpdated = dbContext.employees.Find(id1);
                        Console.WriteLine("Enter your name: ");
                        employeeToBeUpdated.Name = Console.ReadLine();
                        Console.WriteLine("Enter your Address: ");
                        employeeToBeUpdated.Address = Console.ReadLine();
                        dbContext.SaveChanges();
                        break;
                    case 4:
                        Console.WriteLine("Enter your id");
                        int id2 = Convert.ToInt32(Console.ReadLine());
                        Employee employeeToBeDeleted = dbContext.employees.Find(id2);
                        dbContext.employees.Remove(employeeToBeDeleted);
                        dbContext.SaveChanges();
                        break;
                    default:
                        break;

                }

            }
        }
    }
}
