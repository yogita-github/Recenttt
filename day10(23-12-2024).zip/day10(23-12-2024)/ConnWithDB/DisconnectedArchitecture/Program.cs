﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace DisconnectedArchitecture
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string conStr = @"Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=One;Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(conStr);
            string selectQuery = "select * from employees";

            SqlDataAdapter da = new SqlDataAdapter(selectQuery,sqlConnection);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow ro in dt.Rows)
            {
           
                Console.WriteLine($"id = {ro[0]} , name = {ro[1]} , address = {ro[2]} ");
            }


            #region Insert Query
            //accept data
            Console.WriteLine("Enter id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Address");
            string address = Console.ReadLine();

            //entering data in row
            DataRow row = dt.NewRow();
            row["id"] = id;
            row["name"] = name;
            row["address"] = address;
            dt.Rows.Add(row);
            da.Update(dt);

            #endregion


            #region Update Query
            Console.WriteLine("Enter Id");
            int id1 = Convert.ToInt32(Console.ReadLine());

            DataRow empE = dt.Rows.Find(id1);

            Console.WriteLine("Enter your name");
            empE["name1"] = Console.ReadLine();

            Console.WriteLine("Enter your Address");
            empE["address1"] = Console.ReadLine();
            da.Update(dt);
            #endregion


            #region Delete query
            Console.WriteLine("Enter the id of user : ");
            int iddEL = Convert.ToInt32(Console.ReadLine());
            DataRow? delRow = dt.Rows.Find(iddEL);
            delRow.Delete();
            da.Update(dt);
            #endregion
        }
    }
}
