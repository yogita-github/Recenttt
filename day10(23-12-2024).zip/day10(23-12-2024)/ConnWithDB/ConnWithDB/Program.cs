﻿using Microsoft.Data.SqlClient;
using System.Data;




namespace ConnWithDB

{
    internal class Program
    {
        static void Main(string[] args)
        {
            string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=One;Integrated Security=True ";
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            DataColumn col1 = new DataColumn("Id",typeof(int));
            DataColumn col2 = new DataColumn("Name",typeof(string));
            DataColumn col3 = new DataColumn("Address",typeof(string));
            dt.Columns.Add(col1);
            dt.Columns.Add(col2);
            dt.Columns.Add(col3);
            dt.PrimaryKey = new DataColumn[] { col1 };
            SqlConnection conn = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(conStr, conn);
            conn.Open();
            SqlDataReader sqr = cmd.ExecuteReader();
            while (sqr.Read())
            {
                DataRow row = dt.NewRow();
                row["Id"] = Convert.ToInt32(row["Id"]);
                row["Name"] = sqr["Name"].ToString();
                row["Address"] = sqr["Address"].ToString();
                dt.Rows.Add(row);
            }
            conn.Close();
            ds.Tables.Add(dt);
            ds.WriteXml(@"D:\\DotNet\day10(23-12-2024)\ConnWithDB\ConnWithDB\Data\EmpData.xml");
        }
    }
}
