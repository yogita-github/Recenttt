﻿using System.Security.Cryptography.X509Certificates;
namespace _00CoreApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Ip/Op
            //Console.WriteLine("Enter a number");
            //int a = Convert.ToInt32(Console.ReadLine());
            ////Console.WriteLine("Hey Monkey..");
            ////Console.WriteLine(a.ToString());
            //Console.WriteLine("Enter second number");
            //int b = Convert.ToInt32(Console.ReadLine());
            #endregion

            #region static/nonStatic Methods
            //A obj = new A();
            ////Console.WriteLine(obj.Add(10,100).ToString());
            //Console.WriteLine(A.AddStatic(200, 300).ToString());
            ////Console.WriteLine(obj.sub(200,80).ToString());
            //Console.WriteLine(A.multiply(2,3)); 

            //ExceptionHandling exceptionHandling = new ExceptionHandling();
            //Console.WriteLine(exceptionHandling.division(5, 0));
            #endregion

            #region Virtual Inheritance
            //B objb = new B(45, 56, 3, "io");
            //A obja = new A(4, 8);
            //Console.WriteLine(obja.add(4, 7));
            //Console.WriteLine(objb.add(10, 20));
            #endregion

            #region SealedWorkTest
            //ExtendedSealWork es = new ExtendedSealWork(100, 300);
            //es.performOperations();
            //Console.WriteLine(); 
            #endregion

            #region OverrideVirtual
            //Parent p1 = new Parent();
            //p1.show();
            //Child c1 = new Child();
            //c1.show();

            //Parent p = new Child();
            //p.show();
            #endregion

            #region Loops
            Console.WriteLine("Enter one number");
            int n = Convert.ToInt32(Console.ReadLine());

            if (n < 100)
            {
                Console.WriteLine("Number is smaller than 100");
            }
            else if (n == 100)
            {
                Console.WriteLine("Number is 100");
            }

            else if (n > 100 && n < 200)
            {
                Console.WriteLine("Num  is greather than 100 and smaller than 200");
            }
            else
            {
                Console.WriteLine("Number is greater than 200");
            }


            Console.WriteLine("Enter number  for for loop");
            int y = Convert.ToInt32(Console.ReadLine());
            int i = 0;
            for (; i <= y; i++)
            {
                Console.WriteLine(i);
            }


            Console.WriteLine("Enter number  for while loop");
            int y2 = Convert.ToInt32(Console.ReadLine());
            int i2 = 0;
            while (i2 != y2)
            {
                Console.WriteLine(i2);
                i2++;
            }

            int i3 = 0;
            Console.WriteLine("Enter number for do while loop");
            int y3 = Convert.ToInt32(Console.ReadLine());

            do
            {
                Console.WriteLine(i3);
                i3++;

            } while (i3 != y3); 
            #endregion

        }
        
    }

    #region SealedClasses
    //public sealed class sealWork
    //{
    //    private int x;
    //    private int y;

    //    public sealWork(int a, int b)
    //    {
    //        this.x = a;
    //        this.y = b;
    //    }

    //    public int add(int aa, int bb)
    //    {
    //        return aa + bb;
    //    }

    //    public int subtract(int aa, int bb)
    //    {
    //        return aa - bb;
    //    }

    //    public int multiply(int aa, int bb)
    //    {
    //        return aa * bb;
    //    }
    //}

    //public class ExtendedSealWork
    //{
    //    private sealWork work;

    //    public ExtendedSealWork(int a, int b)
    //    {
    //        work = new sealWork(a, b);
    //    }

    //    public void performOperations()
    //    {
    //        Console.WriteLine("Addition: " + work.add(5, 7));
    //        Console.WriteLine("Subtraction: " + work.subtract(10, 3));
    //        Console.WriteLine("Multiplication: " + work.multiply(4, 5));
    //    }
    //} 
    #endregion

    #region exception
    //public class ExceptionHandling
    //{
    //    public int division(int num1, int num2)
    //    {
    //        try
    //        {
    //            if (num2 == 0)
    //            {
    //                throw new Exception("Cannot divide by 0");
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Console.WriteLine(ex.ToString());
    //        }
    //        return num1 / num2;
    //    }
    //} 
    #endregion


    #region class A
    //public class A
    //{
    //    public int Add(int a, int b)
    //    {
    //        return a + b;
    //    }

    //    public static int AddStatic(int a, int b)
    //    {
    //        return a + b;
    //    }
    //    public int sub(int a,int b)
    //    {
    //        return a - b;

    //    }
    //    public static int multiply(int a,int b)
    //    {
    //        return a * b;
    //    }

    //} 
    #endregion

    #region Inheritance classes
    //class A
    //{
    //    int a;
    //    int b;

    //    public A() { }

    //    public A(int a, int b)
    //    {
    //        this.a = a;
    //        this.b = b;

    //    }
    //    public virtual int add(int a, int b)
    //    {
    //        Console.WriteLine("Add from A");
    //        return a + b + 1000;
    //    }

    //}
    //class B : A
    //{
    //    int u;
    //    string name;

    //    public B() { }

    //    public B(int x, int y, int u, string name) : base(x, y)
    //    {
    //        this.u = u;
    //        this.name = name;
    //    }
    //    public override int add(int a, int b)
    //    {
    //        Console.WriteLine("Add from B");
    //        return a + b + u;
    //    }
    //} 
    #endregion

    #region trialInheritanceVirtualOverride
    public class Parent
    {
        public virtual void show()
        {
            Console.WriteLine("Calling from : Parent");
        }
    }

    public class Child : Parent
    {
        public override void show()
        {
            Console.WriteLine("Calling from : Child");
        }
    } 
    #endregion

}