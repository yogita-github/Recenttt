﻿namespace ClassLibrary1
{
    public class DLLFile
    {
        public void Add(int a,int b)
        {
            Console.WriteLine("Addition is : {0}", a + b);
        }
        protected void Subtract(int x,int y)
        {
            Console.WriteLine("Subtraction is : {0}", x - y);
        }
        protected internal void Multiplication(int o,int m)
        {   
            Console.WriteLine( "Multiplication is : {0}",o*m);

        }
        internal void Division(int g,int h)
        {
            Console.WriteLine("Division is :{0} ",g/h);
        }
    }
}
