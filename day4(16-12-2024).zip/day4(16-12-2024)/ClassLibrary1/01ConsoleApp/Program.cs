﻿using ClassLibrary1;

namespace _01ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DLLFile dLL = new DLLFile();
            dLL.Add(100, 200);

            Wr ok = new Wr();
            ok.mult(100, 200);
            
        }
    }

    public class Wr : DLLFile
    {
        public  void sub(int a,int b)
        {
            base.Subtract(a,b);
        }
        public void mult(int a, int b)
        {
            base.Multiplication(a, b);
        }
    }
}
