﻿using System.Collections;
using System.Runtime;

namespace _01Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region SwapTwoWays
            //int a = 10, b = 20;
            //One obj = new One();
            //Console.WriteLine("Normal(Pass by value) Before swap : a = {0} and b = {1}", a, b);
            //obj.swap(a, b);
            //Console.WriteLine("Normal(Pass by value)  After swap : a = {0} and b = {1}", a, b);

            //a = 100; b = 200;
            //Console.WriteLine("(Pass by Refrence) -> Before swap : a = {0} and b = {1}", a, b);
            //obj.swap(ref a, ref b);
            //Console.WriteLine("(Pass by Refrence) -> After swap : a = {0} and b = {1}", a, b); 
            #endregion

            #region TupleAndInOut
            //var ans = Calculator(10, 20);
            //Console.WriteLine(ans.sum);
            //Console.WriteLine(ans.product);
            //Console.WriteLine(ans);
            //int sum;
            //int mult;
            //Testout(2, 6, out sum, out mult);
            //Console.WriteLine(sum);
            //Console.WriteLine(mult); 
            #endregion

            #region Array and ArrayList
            //int[] arr = new int[10];
            //for (int i = 0; i < arr.Length; i++) { 
            //    arr[i] = i;    
            //}
            ////Console.WriteLine(arr[^1]);
            //foreach(int i in arr)
            //{
            //    Console.WriteLine(i);
            //}

            //ArrayList ar = new ArrayList();
            //ar.Add(89);
            //ar.Add(45);
            //ar.Add(35);
            //ar.Add(30);
            //ar.Remove(45);
            //foreach(int b in ar) {
            //    Console.WriteLine(b);
            //} 
            #endregion

            #region asKeyWordAndObjecyList
            //Employee employee = new Employee();
            //employee.A = 100;
            //employee.B = 1000;
            //List<Object> list = new List<Object>();
            //list.Add(100);
            //list.Add("Chan");
            //list.Add(100.200);
            //list.Add(true);
            //list.Add('C');
            //list.Add(employee);

            //foreach (var ab in list)
            //{
            //    if (ab is Employee)
            //    {
            //        Console.WriteLine("Employee");
            //        Employee emp = ab as Employee;
            //        Console.WriteLine("A has :{0} ,B has :{1}", emp.A, emp.B);
            //    }
            //    else
            //        Console.WriteLine(ab);
            //} 

            //List<string> lst = new List<string>();
            //lst.Add("football");
            //lst.Add("vollyball");
            //lst.Add("cricket");
            //lst.Add("badminton");
            //foreach (string item in lst)
            //{
            //    Console.WriteLine(item.ToString());
            //}
            #endregion

            #region tuple_And_Out
            //public static (int sum, int product) Calculator(int a, int b)
            //{
            //    int sum = a + b;
            //    int product = a * b;
            //    return (sum, product);
            //}

            //public static void Testout(int a, int b, out int sum, out int mult)
            //{
            //    sum = a + b;
            //    mult = a * b;
            //} 
            #endregion

            #region Hashtable
            //Hashtable ht = new Hashtable();
            //ht.Add(1, 46);
            //ht.Add(2, 67);
            //ht.Add(3, "hiii");
            //foreach (var key in ht.Keys)
            //{
            //    Console.WriteLine(ht[key]);
            //} 
            #endregion

            #region Stack
            //Stack st = new Stack();
            //st.Push(200);
            //st.Push(300);
            //st.Push(500);
            //st.Push(600);
            //Console.WriteLine("-------------------------------");
            //Console.WriteLine(st.Pop());
            //foreach(int item in st)
            //{   
            //    Console.WriteLine(item);

            //} 
            #endregion

            #region Queue
            //Queue qu = new Queue();
            //qu.Enqueue(10);
            //qu.Enqueue(20);
            //qu.Enqueue(30);
            //qu.Enqueue(50);
            //qu.Enqueue(80);
            //foreach(int item in qu)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("-----------------------");
            //qu.Dequeue();
            //qu.Dequeue();
            //qu.Dequeue();
            //qu.Dequeue();

            //foreach(int i in qu)
            //{
            //    Console.WriteLine(i);
            //} 
            #endregion

            #region Indices and range
            //int[] arr = new int[6];
            //arr[0] = 67;
            //arr[1] = 54;
            //arr[2] = 78;
            //arr[3] = 10;
            //arr[4] = 99;
            //arr[5] = 100;
            //string ans = string.Join(",", arr);
            //Console.WriteLine(ans);

            //int[] subArray = arr[1..3];
            //Console.WriteLine(string.Join(",", subArray));

            //int[] subArray1 = arr[..4];
            //Console.WriteLine(string.Join(",", subArray1));

            //string s = "This is how we can split array using .split operator";
            //string[] ar = s.Split(" ");
            //foreach(string str in ar)
            //{
            //    Console.Write(str + " ");
            //}
            //Console.WriteLine(ar.Contains("is"));
            //Console.WriteLine(ar.Last());
            #endregion

            #region GenericVarying
            //Vision<int,string,double> v = new Vision<int,string,double>();
            //int ans = v.add(100, 200);
            //Console.WriteLine(ans);
            //string str = v.add("one", "two");
            //Console.WriteLine(str);
            //double res = v.add(10.3, 4.6);
            //Console.WriteLine(res); 
            #endregion

            #region IDictionary
            //Dictionary<int, string> dict = new Dictionary<int, string>();
            //dict.Add(1, "helina");
            //dict.Add(2, "omen");
            //dict.Add(3, "Diluc");
            //dict.Add(4, "Ayaka");
            //dict.Add(5, "Shogan");
            //Console.Write("{");
            //foreach(int key in dict.Keys)
            //{
            //    Console.Write(dict[key]+",");
            //}
            //Console.Write("}"); 
            #endregion

            #region GenericSwapCheck
            //string a = "One";
            //string b = "Two";
            //Swap<string>(ref a, ref b);
            //Console.WriteLine("After swap : a = {0} and b = {1}",a,b); 
            #endregion

            #region GenericClassNonGenericFunction
            //CHello<int> ch = new CHello<int>();
            //int a = 23; int b = 45;
            //ch.Swap(ref a, ref b);
            //Console.WriteLine("After swap : a = {0} and b = {1}", a,b);  
            #endregion

        }
        #region GenericSwap
        //public static void Swap<T>(ref T a, ref T b)
        //{
        //    T temp = a;
        //    a = b;
        //    b = temp;
        //} 
        #endregion

        #region GenericClassNonGenericFunction
        //public class CHello<T>
        //{
        //    public void Swap(ref T a, ref T b)
        //    {
        //        T temp = a;
        //        a = b;
        //        b = temp;
        //    }
        //} 
        #endregion


    }

   

    #region Swap class
    //public class One
    //{
    //    public void swap(ref int a, ref int b)
    //    {
    //        int temp = a;
    //        a = b;
    //        b = temp;
    //    }
    //    public void swap(int a, int b)
    //    {
    //        int temp = a;
    //        a = b;
    //        b = temp;
    //    }
    //}  
    #endregion

    #region EmployeeClass
    //public class Employee
    //{
    //    private int a;
    //    private int b;
    //    public int B
    //    {
    //        get { return b; }
    //        set { b = value; }
    //    }
    //    public int A
    //    {
    //        get { return a; }
    //        set { a = value; }
    //    }
    //} 
    #endregion

    #region GenericVarrying
    //public class Vision<A,B,C>
    //{
    //    private A a;
    //    private B b;
    //    private C c;

    //    public A GetA() { return a; }
    //    public B GetB() { return b; }
    //    public C GetC() { return c; }

    //    public void SetA(A aa)
    //    {
    //        this.a = aa;
    //    }
    //    public void SetB(B aa)
    //    {
    //        this.b = aa;
    //    }
    //    public void SetC(C aa)
    //    {
    //        this.c = aa;
    //    }
    //    public A add(A aa,A bb)
    //    {
    //        dynamic prop1 = aa;
    //        dynamic prop2 = bb;
    //        A sum = prop1 + prop2;
    //        return sum;
    //    }
    //    public B add(B aa, B bb)
    //    {
    //        dynamic prop1 = aa;
    //        dynamic prop2 = bb;
    //        B sum = prop1 + prop2;
    //        return sum;
    //    }

    //    public C add(C aa, C bb)
    //    {
    //        dynamic prop1 = aa;
    //        dynamic prop2 = bb;
    //        C sum = prop1 * prop2;
    //        return sum;
    //    } 


//}
#endregion
}